# facial skin diseases > 2024-04-21 8:20pm
https://universe.roboflow.com/facial-skin-dataset/facial-skin-diseases

Provided by a Roboflow user
License: CC BY 4.0

